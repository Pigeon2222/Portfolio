﻿using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        Thread thread;
        TcpListener tcpListener;
        TcpClient tcpClient;
        StreamReader streamReader;
        StreamWriter streamWriter;

        public Form1()
        {
            InitializeComponent();
        }

        private void Start_Click(object sender, System.EventArgs e)
        {
            thread = new Thread(() => connect());
            thread.IsBackground = true;
            thread.Start();
        }

        private void connect()
        {
            tcpListener = new TcpListener(IPAddress.Parse(ip_box.Text), int.Parse(port_box.Text));
            tcpListener.Start();
            System.Console.WriteLine("서버 준비...클라이언트 기다리는 중...");

            tcpClient = tcpListener.AcceptTcpClient();
            System.Console.WriteLine("클라이언트 연결됨...");

            streamReader = new StreamReader(tcpClient.GetStream());
            streamWriter = new StreamWriter(tcpClient.GetStream());
            streamWriter.AutoFlush = true;

            while (tcpClient.Connected)
            {
                string receiveData = streamReader.ReadLine();
                writeTextbox(receiveData);
            }
        }

        private void writeTextbox(string str)
        {
            richTextBox1.Invoke((MethodInvoker)delegate { richTextBox1.AppendText(str + "\r\n"); });
            richTextBox1.Invoke((MethodInvoker)delegate { richTextBox1.ScrollToCaret(); });
        }

        private void ServiceDescription_Click(object sender, System.EventArgs e)
        {
            MachineInfo machineInfo = new MachineInfo();
            machineInfo.m_machineId = "DownstreamSimulation";
            machineInfo.m_laneId = 1;
            machineInfo.m_version = "1.0";
            string sendData = MakeHermesMessage.GetServiceDesc(machineInfo);
            streamWriter.WriteLine(sendData);
        }

        private void BoardAvailable_Click(object sender, System.EventArgs e)
        {
            BoardInfo BoardInfo = new BoardInfo();
            BoardInfo.m_boardId = "boardId_001";
            string sendData = MakeHermesMessage.GetBoardAvailable(BoardInfo);
            streamWriter.WriteLine(sendData);
        }

        private void RevokeBoardAvailable_Click(object sender, System.EventArgs e)
        {
            string sendData = MakeHermesMessage.GetRevokeBoardAvailable();
            streamWriter.WriteLine(sendData);
        }

        private void TransportFinished_Click(object sender, System.EventArgs e)
        {
            string sendData = MakeHermesMessage.GetTransportFinished("COMPLETE", "boardId_001");
            streamWriter.WriteLine(sendData);
        }

        private void Reset_Click(object sender, System.EventArgs e)
        {
            string sendData = MakeHermesMessage.GetNotification(NotificationCode.Configuration_error, Severity.Error, "");
            streamWriter.WriteLine(sendData);
        }

        private void Notification_Click(object sender, System.EventArgs e)
        {
            string sendData = MakeHermesMessage.GetNotification(NotificationCode.Configuration_error, Severity.Error, "");
            streamWriter.WriteLine(sendData);
        }

        private void CheckAlive_Click(object sender, System.EventArgs e)
        {
            string sendData = MakeHermesMessage.GetCheckAlive();
            streamWriter.WriteLine(sendData);
        }
    }
}