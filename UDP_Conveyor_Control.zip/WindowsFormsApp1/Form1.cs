﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int submit = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void read_button_Click(object sender, EventArgs e)
        {
            get_point();
        }

        private void go_button_Click(object sender, EventArgs e)
        {
            set_point();
        }

        public void get_point()
        {
            try
            {
                char code = read_box1.Text[0];
                char word = read_box2.Text[0];
                byte[] bytes = Udp($"<01#RCS{code}000{word}**\r");

                if (bytes[6] == '1')
                    MessageBox.Show("ON");
                else
                    MessageBox.Show("OFF");
            }
            catch (Exception)
            {
                Console.WriteLine("get_point 오류!");
            }
        }

        public void set_point()
        {
            try
            {
                char code = read_box1.Text[0];
                char word = read_box2.Text[0];
                char data = read_box3.Text[0];
                Udp($"<01#WCS{code}000{word}{data}**\r");
                MessageBox.Show("전송 성공!");
            }
            catch (Exception)
            {
                Console.WriteLine("set_point 오류!");
            }
        }

        public byte[] Udp(string msg)
        {
            // (1) UdpClient 객체 성성
            UdpClient cli = new UdpClient();
            byte[] datagram = Encoding.UTF8.GetBytes(msg);

            // (2) 데이타 송신
            cli.Send(datagram, datagram.Length, "127.0.0.1", 8000);
            // WriteLine("[Send] 127.0.0.1:7777 로 {0} 바이트 전송", datagram.Length);

            // (3) 데이타 수신
            IPEndPoint epRemote = new IPEndPoint(IPAddress.Any, 0);
            byte[] bytes = cli.Receive(ref epRemote);
            // WriteLine("[Receive] {0} 로부터 {1} 바이트 수신", epRemote.ToString(), bytes.Length);

            // (4) UdpClient 객체 닫기
            cli.Close();

            return bytes;
        }



        // 컨베이어 제어, 0이 켜져 있을 때 동작버튼을 누르면 작동
        private void button1_Click(object sender, EventArgs e)
        {
            thread_Start('R');
        }

        private void button2_Click(object sender, EventArgs e)
        {
            thread_Start('X');
        }

        private void button3_Click(object sender, EventArgs e)
        {
            thread_Start('Y');
        }

        public void thread_Start(char code)
        {
            Thread thread = new Thread(ReceiveMsgHandleThread);
            thread.IsBackground = true;
            thread.Start(code);
            System.Console.WriteLine($"{code} 컨베이어 작동 ON");
        }

        private void ReceiveMsgHandleThread(object obj)
        {
            char code = (char)obj;
            int step = 100;
            Thread.Sleep(200);
            while (true)
            {
                switch (step)
                {
                    case 100:
                        step += work_step(code, 48, 100);
                        break;
                    case 200:
                        step += work_step(code, 49, 200);
                        break;
                    case 300:
                        step += work_step(code, 50, 300);
                        break;
                    case 400:
                        step += work_step(code, 51, 400);
                        break;
                    case 500:
                        step += work_step(code, 52, 500);
                        break;
                    case 600:
                        step += work_step(code, 53, 600);
                        break;
                    case 700:
                        step += work_step(code, 54, 700);
                        break;
                    case 800:
                        step += work_step(code, 55, 800);
                        break;
                    case 900:
                        step += work_step(code, 56, 900);
                        break;
                    case 1000:
                        step += work_step(code, 57, 1000);
                        break;
                    case 1100:
                        step += work_step(code, 65, 1100);
                        break;
                    case 1200:
                        step += work_step(code, 66, 1200);
                        break;
                    case 1300:
                        step += work_step(code, 67, 1300);
                        break;
                    case 1400:
                        step += work_step(code, 68, 1400);
                        break;
                    case 1500:
                        step += work_step(code, 69, 1500);
                        break;
                    case 1600:
                        step -= work_step(code, 70, 1600);
                        break;
                }
            }
        }

        public int work_step(char code, int num, int step)
        {
            if (step == 100)
            {
                if ('1' == get_point(code, (char)num))
                {
                    set_point(code, (char)(num + 1), '1');
                    System.Console.WriteLine($"{code} 컨베이어 공정{step / 100} 완료");
                    Thread.Sleep(200);
                    return 100;
                }
                return 0;
            }
            else if (step == 1000)
            {
                if ('1' == get_point(code, (char)num))
                {
                    set_point(code, (char)num, '0');
                    set_point(code, (char)65, '1');
                    System.Console.WriteLine($"{code} 컨베이어 공정{step / 100} 완료");
                    Thread.Sleep(200);
                    return 100;
                }
                return 0;
            }
            else if (step == 1600)
            {
                if ('1' == get_point(code, (char)num))
                {
                    set_point(code, (char)num, '0');
                    System.Console.WriteLine("최종공정 완료!");
                    submit++;
                    Console.WriteLine($"현재 완성품 {submit}개!");
                    Thread.Sleep(200);
                    return 1500;
                }
                return 0;
            }
            else
            {
                if ('1' == get_point(code, (char)num))
                {
                    set_point(code, (char)num, '0');
                    set_point(code, (char)(num + 1), '1');
                    System.Console.WriteLine($"{code} 컨베이어 공정{step / 100} 완료");
                    Thread.Sleep(200);
                    return 100;
                }
                return 0;
            }
        }

        public char get_point(char code, char word)
        {
            try
            {
                byte[] bytes = Udp($"<01#RCS{code}000{word}**\r");

                if (bytes[6] == '1')
                {
                    // System.Console.WriteLine("ON");
                }
                else
                {
                    // System.Console.WriteLine("OFF");
                }

                return (char)bytes[6];
            }
            catch (Exception)
            {
                Console.WriteLine("get_point! 오류!");
            }
            return '0';
        }

        public void set_point(char code, char word, char data)
        {
            try
            {
                Udp($"<01#WCS{code}000{word}{data}**\r");
            }
            catch (Exception)
            {
                Console.WriteLine("set_point! 오류!");
            }
        }
    }
}
