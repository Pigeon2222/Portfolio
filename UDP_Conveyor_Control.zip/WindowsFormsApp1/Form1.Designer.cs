﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.go_label3 = new System.Windows.Forms.Label();
            this.read_box3 = new System.Windows.Forms.TextBox();
            this.read_box2 = new System.Windows.Forms.TextBox();
            this.read_button = new System.Windows.Forms.Button();
            this.read_box1 = new System.Windows.Forms.TextBox();
            this.go_label2 = new System.Windows.Forms.Label();
            this.go_button = new System.Windows.Forms.Button();
            this.go_label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // go_label3
            // 
            this.go_label3.AutoSize = true;
            this.go_label3.Location = new System.Drawing.Point(475, 154);
            this.go_label3.Name = "go_label3";
            this.go_label3.Size = new System.Drawing.Size(21, 12);
            this.go_label3.TabIndex = 16;
            this.go_label3.Text = "0 1";
            // 
            // read_box3
            // 
            this.read_box3.Location = new System.Drawing.Point(460, 169);
            this.read_box3.Name = "read_box3";
            this.read_box3.Size = new System.Drawing.Size(50, 21);
            this.read_box3.TabIndex = 12;
            // 
            // read_box2
            // 
            this.read_box2.Location = new System.Drawing.Point(370, 169);
            this.read_box2.Name = "read_box2";
            this.read_box2.Size = new System.Drawing.Size(50, 21);
            this.read_box2.TabIndex = 11;
            // 
            // read_button
            // 
            this.read_button.Location = new System.Drawing.Point(301, 227);
            this.read_button.Name = "read_button";
            this.read_button.Size = new System.Drawing.Size(75, 23);
            this.read_button.TabIndex = 14;
            this.read_button.Text = "읽기";
            this.read_button.UseVisualStyleBackColor = true;
            this.read_button.Click += new System.EventHandler(this.read_button_Click);
            // 
            // read_box1
            // 
            this.read_box1.Location = new System.Drawing.Point(280, 169);
            this.read_box1.Name = "read_box1";
            this.read_box1.Size = new System.Drawing.Size(50, 21);
            this.read_box1.TabIndex = 10;
            // 
            // go_label2
            // 
            this.go_label2.AutoSize = true;
            this.go_label2.Location = new System.Drawing.Point(378, 154);
            this.go_label2.Name = "go_label2";
            this.go_label2.Size = new System.Drawing.Size(35, 12);
            this.go_label2.TabIndex = 13;
            this.go_label2.Text = "0 ~ F";
            // 
            // go_button
            // 
            this.go_button.Location = new System.Drawing.Point(416, 227);
            this.go_button.Name = "go_button";
            this.go_button.Size = new System.Drawing.Size(75, 23);
            this.go_button.TabIndex = 15;
            this.go_button.Text = "전송";
            this.go_button.UseVisualStyleBackColor = true;
            this.go_button.Click += new System.EventHandler(this.go_button_Click);
            // 
            // go_label1
            // 
            this.go_label1.AutoSize = true;
            this.go_label1.Location = new System.Drawing.Point(287, 154);
            this.go_label1.Name = "go_label1";
            this.go_label1.Size = new System.Drawing.Size(37, 12);
            this.go_label1.TabIndex = 9;
            this.go_label1.Text = "R X Y";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(271, 281);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "R 동작";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(359, 281);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 18;
            this.button2.Text = "X 동작";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(447, 281);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 19;
            this.button3.Text = "Y 동작";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.go_label3);
            this.Controls.Add(this.read_box3);
            this.Controls.Add(this.read_box2);
            this.Controls.Add(this.read_button);
            this.Controls.Add(this.read_box1);
            this.Controls.Add(this.go_label2);
            this.Controls.Add(this.go_button);
            this.Controls.Add(this.go_label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label go_label3;
        private System.Windows.Forms.TextBox read_box3;
        private System.Windows.Forms.TextBox read_box2;
        private System.Windows.Forms.Button read_button;
        private System.Windows.Forms.TextBox read_box1;
        private System.Windows.Forms.Label go_label2;
        private System.Windows.Forms.Button go_button;
        private System.Windows.Forms.Label go_label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

