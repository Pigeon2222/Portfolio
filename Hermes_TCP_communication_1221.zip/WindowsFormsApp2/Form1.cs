﻿using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        StreamReader streamReader1;
        StreamWriter streamWriter1;

        private void Start_Click(object sender, System.EventArgs e)
        {
            Thread thread1 = new Thread(connect);
            thread1.IsBackground = true;
            thread1.Start();
        }

        private void connect()
        {
            TcpListener tcpListener1 = new TcpListener(IPAddress.Parse(ip_box.Text), int.Parse(port_box.Text));
            tcpListener1.Start();
            System.Console.WriteLine("서버 준비...클라이언트 기다리는 중...");

            TcpClient tcpClient1 = tcpListener1.AcceptTcpClient();
            System.Console.WriteLine("클라이언트 연결됨...");

            streamReader1 = new StreamReader(tcpClient1.GetStream());
            streamWriter1 = new StreamWriter(tcpClient1.GetStream());
            streamWriter1.AutoFlush = true;

            while (tcpClient1.Connected)
            {
                string receiveData1 = streamReader1.ReadLine();
                writeTextbox(receiveData1);
            }
        }

        private void writeTextbox(string str)
        {
            richTextBox1.Invoke((MethodInvoker)delegate { richTextBox1.AppendText(str + "\r\n"); });
            richTextBox1.Invoke((MethodInvoker)delegate { richTextBox1.ScrollToCaret(); });
        }

        private void ServiceDescription_Click(object sender, System.EventArgs e)
        {
            MachineInfo machineInfo = new MachineInfo();
            machineInfo.m_interfaceId = "InterfaceId";
            machineInfo.m_laneId = 1;
            machineInfo.m_version = "1.0";
            string sendData1 = MakeHermesMessage.GetServiceDesc(machineInfo);
            streamWriter1.WriteLine(sendData1);
        }

        private void BoardAvailable_Click(object sender, System.EventArgs e)
        {
            BoardInfo BoardInfo = new BoardInfo();
            BoardInfo.m_boardId = "boardId";
            string sendData1 = MakeHermesMessage.GetBoardAvailable(BoardInfo);
            streamWriter1.WriteLine(sendData1);
        }

        private void RevokeBoardAvailable_Click(object sender, System.EventArgs e)
        {
            string sendData1 = MakeHermesMessage.GetRevokeBoardAvailable();
            streamWriter1.WriteLine(sendData1);
        }

        private void TransportFinished_Click(object sender, System.EventArgs e)
        {
            string sendData1 = MakeHermesMessage.GetTransportFinished(1, "boardId");
            streamWriter1.WriteLine(sendData1);
        }

        private void Reset_Click(object sender, System.EventArgs e)
        {
            writeTextbox(null);
        }

        private void Notification_Click(object sender, System.EventArgs e)
        {
            Notification Notification = new Notification();
            string sendData1 = MakeHermesMessage.GetNotification(NotificationCode.Configuration_error, Severity.Error, "");
            streamWriter1.WriteLine(sendData1);
        }

        private void CheckAlive_Click(object sender, System.EventArgs e)
        {
            string sendData1 = MakeHermesMessage.GetCheckAlive();
            streamWriter1.WriteLine(sendData1);
        }
    }
}