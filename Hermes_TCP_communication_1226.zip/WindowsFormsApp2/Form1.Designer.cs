﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Start = new System.Windows.Forms.Button();
            this.ServiceDescription = new System.Windows.Forms.Button();
            this.BoardAvailable = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ip_box = new System.Windows.Forms.TextBox();
            this.port_box = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.TransportFinished = new System.Windows.Forms.Button();
            this.RevokeBoardAvailable = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.Notification = new System.Windows.Forms.Button();
            this.CheckAlive = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Start
            // 
            this.Start.Location = new System.Drawing.Point(171, 27);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(75, 23);
            this.Start.TabIndex = 0;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // ServiceDescription
            // 
            this.ServiceDescription.Location = new System.Drawing.Point(146, 56);
            this.ServiceDescription.Name = "ServiceDescription";
            this.ServiceDescription.Size = new System.Drawing.Size(125, 23);
            this.ServiceDescription.TabIndex = 1;
            this.ServiceDescription.Text = "Service Description";
            this.ServiceDescription.UseVisualStyleBackColor = true;
            this.ServiceDescription.Click += new System.EventHandler(this.ServiceDescription_Click);
            // 
            // BoardAvailable
            // 
            this.BoardAvailable.Location = new System.Drawing.Point(146, 85);
            this.BoardAvailable.Name = "BoardAvailable";
            this.BoardAvailable.Size = new System.Drawing.Size(125, 23);
            this.BoardAvailable.TabIndex = 2;
            this.BoardAvailable.Text = "Board Available";
            this.BoardAvailable.UseVisualStyleBackColor = true;
            this.BoardAvailable.Click += new System.EventHandler(this.BoardAvailable_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Server IP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Port Number";
            // 
            // ip_box
            // 
            this.ip_box.Location = new System.Drawing.Point(24, 103);
            this.ip_box.Name = "ip_box";
            this.ip_box.Size = new System.Drawing.Size(100, 21);
            this.ip_box.TabIndex = 9;
            this.ip_box.Text = "127.0.0.1";
            // 
            // port_box
            // 
            this.port_box.Location = new System.Drawing.Point(24, 149);
            this.port_box.Name = "port_box";
            this.port_box.Size = new System.Drawing.Size(100, 21);
            this.port_box.TabIndex = 10;
            this.port_box.Text = "50101";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(24, 266);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(247, 157);
            this.richTextBox1.TabIndex = 15;
            this.richTextBox1.Text = "";
            // 
            // TransportFinished
            // 
            this.TransportFinished.Location = new System.Drawing.Point(146, 143);
            this.TransportFinished.Name = "TransportFinished";
            this.TransportFinished.Size = new System.Drawing.Size(125, 23);
            this.TransportFinished.TabIndex = 4;
            this.TransportFinished.Text = "Transport Finished";
            this.TransportFinished.UseVisualStyleBackColor = true;
            this.TransportFinished.Click += new System.EventHandler(this.TransportFinished_Click);
            // 
            // RevokeBoardAvailable
            // 
            this.RevokeBoardAvailable.Font = new System.Drawing.Font("굴림", 7F);
            this.RevokeBoardAvailable.Location = new System.Drawing.Point(146, 114);
            this.RevokeBoardAvailable.Name = "RevokeBoardAvailable";
            this.RevokeBoardAvailable.Size = new System.Drawing.Size(125, 23);
            this.RevokeBoardAvailable.TabIndex = 3;
            this.RevokeBoardAvailable.Text = "Revoke Board Available";
            this.RevokeBoardAvailable.UseVisualStyleBackColor = true;
            this.RevokeBoardAvailable.Click += new System.EventHandler(this.RevokeBoardAvailable_Click);
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(146, 172);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(125, 23);
            this.Reset.TabIndex = 5;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // Notification
            // 
            this.Notification.Location = new System.Drawing.Point(146, 201);
            this.Notification.Name = "Notification";
            this.Notification.Size = new System.Drawing.Size(125, 23);
            this.Notification.TabIndex = 6;
            this.Notification.Text = "Notification";
            this.Notification.UseVisualStyleBackColor = true;
            this.Notification.Click += new System.EventHandler(this.Notification_Click);
            // 
            // CheckAlive
            // 
            this.CheckAlive.Location = new System.Drawing.Point(146, 230);
            this.CheckAlive.Name = "CheckAlive";
            this.CheckAlive.Size = new System.Drawing.Size(125, 23);
            this.CheckAlive.TabIndex = 7;
            this.CheckAlive.Text = "Check Alive";
            this.CheckAlive.UseVisualStyleBackColor = true;
            this.CheckAlive.Click += new System.EventHandler(this.CheckAlive_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 450);
            this.Controls.Add(this.CheckAlive);
            this.Controls.Add(this.Notification);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.RevokeBoardAvailable);
            this.Controls.Add(this.TransportFinished);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.port_box);
            this.Controls.Add(this.ip_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BoardAvailable);
            this.Controls.Add(this.ServiceDescription);
            this.Controls.Add(this.Start);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.Button ServiceDescription;
        private System.Windows.Forms.Button BoardAvailable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ip_box;
        private System.Windows.Forms.TextBox port_box;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button TransportFinished;
        private System.Windows.Forms.Button RevokeBoardAvailable;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button Notification;
        private System.Windows.Forms.Button CheckAlive;
    }
}

