﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace TCP_IP_program
{
    public class Cli : Common_function
    {
        // 클라이언트 연결
        public void Cli_connect(Form1 form)
        {
            form1 = form;

            try
            {
                Enabled_box_and_button(false);

                tcpClient = new TcpClient();
                IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse(form1.IP_box.Text), int.Parse(form1.Port_box.Text));
                Connect_text_show("서버 기다리는 중...", "B");

                tcpClient.Connect(ipEnd);
                Connect_text_show("서버와 연결됨.", "G");
                Timeout(); // 타임아웃 값 받아서 타임아웃 설정

                while (true)
                {
                    Connecting();
                }
            }
            catch (Exception)
            {
                Cli_connect_stop();
            }
        }

        // 연결 상태 초기화
        public void Cli_connect_stop()
        {
            try
            {
                Enabled_box_and_button(true);

                tcpClient.Close();
                form1.thread_cli = null;
                Connect_text_show("연결 안됨.", "R");
            }
            catch (Exception)
            {
                MessageBox.Show("클라이언트 연결 중지 오류");
            }
        }

        // 타임아웃
        private void Timeout()
        {
            tcpClient.SendTimeout = int.Parse(form1.TimeOut_box.Text) * 1000; // 송신 대기시간 설정
            tcpClient.ReceiveTimeout = int.Parse(form1.TimeOut_box.Text) * 1000; // 수신 대기시간 설정
        }
    }
}
