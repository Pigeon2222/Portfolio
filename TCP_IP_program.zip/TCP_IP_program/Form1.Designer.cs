﻿namespace TCP_IP_program
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Server_go = new System.Windows.Forms.Button();
            this.Cli_go = new System.Windows.Forms.Button();
            this.IP_box = new System.Windows.Forms.TextBox();
            this.Port_box = new System.Windows.Forms.TextBox();
            this.Connect_text = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SendMSG_box = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Connect_stop = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.TimeOut_box = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.MSG_go = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.MSG_save = new System.Windows.Forms.Button();
            this.GetMSG_box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.AutoMSG_box = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Server_go
            // 
            this.Server_go.Location = new System.Drawing.Point(9, 123);
            this.Server_go.Name = "Server_go";
            this.Server_go.Size = new System.Drawing.Size(75, 23);
            this.Server_go.TabIndex = 0;
            this.Server_go.Text = "Server_go";
            this.Server_go.UseVisualStyleBackColor = true;
            this.Server_go.Click += new System.EventHandler(this.Server_go_Click);
            // 
            // Cli_go
            // 
            this.Cli_go.Location = new System.Drawing.Point(91, 123);
            this.Cli_go.Name = "Cli_go";
            this.Cli_go.Size = new System.Drawing.Size(75, 23);
            this.Cli_go.TabIndex = 1;
            this.Cli_go.Text = "Cli_go";
            this.Cli_go.UseVisualStyleBackColor = true;
            this.Cli_go.Click += new System.EventHandler(this.Cli_go_Click);
            // 
            // IP_box
            // 
            this.IP_box.Location = new System.Drawing.Point(41, 37);
            this.IP_box.Name = "IP_box";
            this.IP_box.Size = new System.Drawing.Size(125, 21);
            this.IP_box.TabIndex = 2;
            this.IP_box.Text = "127.0.0.1";
            // 
            // Port_box
            // 
            this.Port_box.Location = new System.Drawing.Point(41, 65);
            this.Port_box.Name = "Port_box";
            this.Port_box.Size = new System.Drawing.Size(125, 21);
            this.Port_box.TabIndex = 3;
            this.Port_box.Text = "5000";
            // 
            // Connect_text
            // 
            this.Connect_text.AutoSize = true;
            this.Connect_text.ForeColor = System.Drawing.Color.Red;
            this.Connect_text.Location = new System.Drawing.Point(3, 155);
            this.Connect_text.Name = "Connect_text";
            this.Connect_text.Size = new System.Drawing.Size(61, 12);
            this.Connect_text.TabIndex = 4;
            this.Connect_text.Text = "연결 안됨.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "IP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Port";
            // 
            // SendMSG_box
            // 
            this.SendMSG_box.Location = new System.Drawing.Point(9, 214);
            this.SendMSG_box.Name = "SendMSG_box";
            this.SendMSG_box.Size = new System.Drawing.Size(157, 21);
            this.SendMSG_box.TabIndex = 7;
            this.SendMSG_box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Enter_KeyDown);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(577, 323);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.Connect_stop);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.TimeOut_box);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.richTextBox2);
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Controls.Add(this.MSG_go);
            this.tabPage1.Controls.Add(this.Server_go);
            this.tabPage1.Controls.Add(this.Cli_go);
            this.tabPage1.Controls.Add(this.SendMSG_box);
            this.tabPage1.Controls.Add(this.IP_box);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.Port_box);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.Connect_text);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(569, 297);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main";
            // 
            // Connect_stop
            // 
            this.Connect_stop.Location = new System.Drawing.Point(40, 176);
            this.Connect_stop.Name = "Connect_stop";
            this.Connect_stop.Size = new System.Drawing.Size(94, 23);
            this.Connect_stop.TabIndex = 24;
            this.Connect_stop.Text = "Connect_stop";
            this.Connect_stop.UseVisualStyleBackColor = true;
            this.Connect_stop.Click += new System.EventHandler(this.Connect_stop_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "Time out";
            // 
            // TimeOut_box
            // 
            this.TimeOut_box.Location = new System.Drawing.Point(70, 93);
            this.TimeOut_box.Name = "TimeOut_box";
            this.TimeOut_box.Size = new System.Drawing.Size(96, 21);
            this.TimeOut_box.TabIndex = 22;
            this.TimeOut_box.Text = "1000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(369, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "수신 MSG";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(173, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "송신 MSG";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(371, 19);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(183, 270);
            this.richTextBox2.TabIndex = 18;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(175, 19);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(183, 270);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            // 
            // MSG_go
            // 
            this.MSG_go.Location = new System.Drawing.Point(50, 241);
            this.MSG_go.Name = "MSG_go";
            this.MSG_go.Size = new System.Drawing.Size(75, 23);
            this.MSG_go.TabIndex = 17;
            this.MSG_go.Text = "MSG_go";
            this.MSG_go.UseVisualStyleBackColor = true;
            this.MSG_go.Click += new System.EventHandler(this.MSG_send_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.richTextBox4);
            this.tabPage2.Controls.Add(this.richTextBox3);
            this.tabPage2.Controls.Add(this.MSG_save);
            this.tabPage2.Controls.Add(this.GetMSG_box);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.AutoMSG_box);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(569, 297);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "autoMSG";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(381, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 12);
            this.label10.TabIndex = 24;
            this.label10.Text = "autoMSG";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(196, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 12);
            this.label11.TabIndex = 23;
            this.label11.Text = "getMSG";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(381, 21);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(182, 270);
            this.richTextBox4.TabIndex = 22;
            this.richTextBox4.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(196, 21);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(182, 270);
            this.richTextBox3.TabIndex = 21;
            this.richTextBox3.Text = "";
            // 
            // MSG_save
            // 
            this.MSG_save.Location = new System.Drawing.Point(56, 155);
            this.MSG_save.Name = "MSG_save";
            this.MSG_save.Size = new System.Drawing.Size(75, 23);
            this.MSG_save.TabIndex = 16;
            this.MSG_save.Text = "MSG_save";
            this.MSG_save.UseVisualStyleBackColor = true;
            this.MSG_save.Click += new System.EventHandler(this.MSG_save_Click);
            // 
            // GetMSG_box
            // 
            this.GetMSG_box.Location = new System.Drawing.Point(67, 98);
            this.GetMSG_box.Name = "GetMSG_box";
            this.GetMSG_box.Size = new System.Drawing.Size(125, 21);
            this.GetMSG_box.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "autoMSG";
            // 
            // AutoMSG_box
            // 
            this.AutoMSG_box.Location = new System.Drawing.Point(67, 127);
            this.AutoMSG_box.Name = "AutoMSG_box";
            this.AutoMSG_box.Size = new System.Drawing.Size(125, 21);
            this.AutoMSG_box.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "getMSG";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 328);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.TextBox IP_box;
        public System.Windows.Forms.Button Server_go;
        public System.Windows.Forms.Button Cli_go;
        public System.Windows.Forms.Label Connect_text;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox SendMSG_box;
        public System.Windows.Forms.TabControl tabControl1;
        public System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.Button MSG_save;
        public System.Windows.Forms.TextBox GetMSG_box;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox AutoMSG_box;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Button MSG_go;
        public System.Windows.Forms.RichTextBox richTextBox2;
        public System.Windows.Forms.RichTextBox richTextBox1;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox TimeOut_box;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.RichTextBox richTextBox4;
        public System.Windows.Forms.RichTextBox richTextBox3;
        public System.Windows.Forms.Button Connect_stop;
        public System.Windows.Forms.TextBox Port_box;
    }
}

