﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace TCP_IP_program
{
    public class Server : Common_function
    {
        // 서버 연결
        public void Server_connect(Form1 form)
        {
            form1 = form;

            try // 연결오류로 프로그램 종료 방지
            {
                Enabled_box_and_button(false); // 박스 및 버튼 조정

                tcpListener = new TcpListener(IPAddress.Parse(form1.IP_box.Text), int.Parse(form1.Port_box.Text));
                tcpListener.Start(); // 서버 시작

                while (true)
                {
                    Connect_text_show("클라이언트 기다리는 중...", "B"); // 글자 및 색으로 연결상태 표시
                    tcpClient = tcpListener.AcceptTcpClient(); // 연결 보류 중인 클라이언트가 있으면 연결
                    Connect_text_show("클라이언트와 연결됨.", "G");
                    Connecting(); // 연결 및 수신상태
                }
            }
            catch (Exception)
            {
                Server_connect_stop(); // 연결종료시 관련된 객체 및 스레드 종료 (연결 종료 후 재연결 위함)
            }
        }

        // 연결 상태 초기화
        public void Server_connect_stop()
        {
            try
            {
                Enabled_box_and_button(true);

                tcpListener.Stop(); // 서버 종료
                form1.thread_server = null;
                Connect_text_show("연결 안됨.", "R"); // 연결 상태 표시 최신화
            }
            catch (Exception)
            {
                MessageBox.Show("서버 연결 중지 오류");
            }
        }
    }
}
