﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace TCP_IP_program
{
    public abstract class Common_function
    {
        protected Form1 form1;
        protected TcpListener tcpListener;
        protected TcpClient tcpClient;

        private int reply_autoNum = 0; // 자동 회신 번호
        private string[] reply_get_MSG = new string[10]; // 자동회신 받을 메시지 배열
        private string[] reply_send_MSG = new string[10]; // 자동회신 보낼 메시지 배열

        // 제어문자표
        public string[] control_string = { "NUL", "SOH", "STX", "ETX", "EOT",
            "ENQ", "ACK", "BEL", "BS", "SO", "SI", "DLE", "DC1", "DC2", "DC3",
            "DC4", "NAK", "SYN", "ETB", "CAN", "EM", "SUB", "ESC", "FS", "GS",
            "RS", "US"};

        // 제어문자표에 대응되는 정수값
        private int[] control_int = { 0, 1, 2, 3, 4,
            5, 6, 7, 8, 14, 15, 16, 17, 18, 19,
            20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
            30, 31};

        // 박스 및 버튼 조정
        protected void Enabled_box_and_button(Boolean boolean)
        {
            form1.Server_go.BeginInvoke((MethodInvoker)delegate { form1.IP_box.Enabled = boolean; });
            form1.Cli_go.BeginInvoke((MethodInvoker)delegate { form1.Port_box.Enabled = boolean; });
            form1.Cli_go.BeginInvoke((MethodInvoker)delegate { form1.TimeOut_box.Enabled = boolean; });
            form1.Server_go.BeginInvoke((MethodInvoker)delegate { form1.Server_go.Enabled = boolean; });
            form1.Cli_go.BeginInvoke((MethodInvoker)delegate { form1.Cli_go.Enabled = boolean; });
        }

        // 연결상태 표시
        protected void Connect_text_show(string text, string RGB)
        {
            form1.Connect_text.BeginInvoke((MethodInvoker)delegate { form1.Connect_text.Text = text; });

            if (RGB == "B")
            {
                form1.Connect_text.ForeColor = Color.Black; // 상태에 맞게 글자색 변경 (검정:연결시도중, 초록:연결됨, 빨강:연결안됨)
            }
            else if (RGB == "G")
            {
                form1.Connect_text.ForeColor = Color.Green;
            }
            else if (RGB == "R")
            {
                form1.Connect_text.ForeColor = Color.Red;
            }
        }

        // 연결 및 수신상태
        protected void Connecting()
        {
            NetworkStream networkStream = tcpClient.GetStream(); // 읽고 쓰기 작업을 하는 객체 생성

            while (tcpClient.Connected)
            {
                byte[] receiveBuffer = new byte[1024]; // 수신 받을 바이트 배열 생성
                int bytesReceived = networkStream.Read(receiveBuffer, 0, receiveBuffer.Length); // 수신 메시지 길이 확인
                receiveBuffer[bytesReceived] = 10; // 줄띄움을 위한 개행 입력
                string receiveString = Encoding.Default.GetString(receiveBuffer).Trim('\0'); // \0 삭제 및 문자열로 변환
                if (bytesReceived == 0) // 수신 메시지 길이가 0이면 반복문 탈출 (연결 해제시 수신 방지)
                {
                    break;
                }
                MSG_reception(receiveString);
            }
            networkStream.Close(); // 메모리 누수를 막기 위한 객체 종료
            tcpClient.Close();
        }

        // 메시지 수신
        private void MSG_reception(string str)
        {
            Write_get(str); // 수신창 출력
            Control_Write_get(str); // 수신 메시지가 제어문자라면 추가 출력
            Reply_MSG_check(str); // 자동회신 받을 메시지인지 확인
        }

        // 수신창 출력
        private void Write_get(string str)
        {
            form1.richTextBox2.BeginInvoke((MethodInvoker)delegate { form1.richTextBox2.AppendText(str); }); // 수신창 출력
            form1.richTextBox2.BeginInvoke((MethodInvoker)delegate { form1.richTextBox2.ScrollToCaret(); }); // 스크롤 다운
        }

        // 송신창 출력
        private void Write_send(string str)
        {
            form1.richTextBox1.BeginInvoke((MethodInvoker)delegate { form1.richTextBox1.AppendText(str + "\n"); }); // 송신창 출력
            form1.richTextBox1.BeginInvoke((MethodInvoker)delegate { form1.richTextBox1.ScrollToCaret(); }); // 스크롤 다운
        }

        // 제어문자 추가 출력
        private void Control_Write_get(string str)
        {
            try
            {
                char[] values = str.ToCharArray(); // 입력받은 문자열을 문자 배열로 변환
                foreach (char letter in values)
                {
                    int value = Convert.ToInt32(letter); // letter은 제어문자(char), value는 16진수 문자
                    int num = (int)Convert.ToDecimal(value); // num은 10진수 정수

                    for (int i = 0; i < control_int.Length; i++) // num이 제어문자 정수표에 있는지 확인
                    {
                        if (num == control_int[i])
                        {
                            Write_get($"제어문자 : {control_string[i]}\n"); // 정수표에 있다면 대응되는 문자열 출력
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        // 자동회신 메시지 설정
        public void Reply_MSG_save()
        {
            if (form1.GetMSG_box.Text == "" || form1.AutoMSG_box.Text == "")
            // 자동회신 받을 메시지와 보낼 메시지 둘 중 하나라도 공백이면 실행 안함
            {
                return;
            }

            reply_get_MSG[reply_autoNum] = form1.GetMSG_box.Text; // 받을 메시지 배열에 저장
            reply_send_MSG[reply_autoNum] = form1.AutoMSG_box.Text; // 보낼 메시지 배열에 저장
            form1.richTextBox3.Text += $"[{reply_autoNum + 1}] {reply_get_MSG[reply_autoNum]}\n";
            // 수신 리스트 박스에 출력
            form1.richTextBox4.Text += $"[{reply_autoNum + 1}] {reply_send_MSG[reply_autoNum]}\n";
            // 송신 리스트 박스에 출력
            form1.GetMSG_box.Text = ""; // 받을 메시지창 초기화
            form1.AutoMSG_box.Text = ""; // 보낼 메시지창 초기화

            if (reply_autoNum == 9) // 현재 설정된 회신 최대값이 10개이기에 9번이면 0번으로 돌아감
            {
                reply_autoNum = 0;
                return;
            }
            reply_autoNum++; // 자동 회신 번호 증가 (배열 위치 변경을 위함)
        }

        // 자동회신 실행
        private void Reply_MSG_check(string str)
        {
            for (int i = 0; i < 10; i++) // 자동회신 최대값까지 확인
            {
                if (str == reply_get_MSG[i] + "\n") // 자동회신 배열에 있는 값과 수신 받은 메시지가 일치하면 자동 회신
                {
                    MSG_send(i); // 해당 자동회신 메시지 송신
                }
            }
        }

        // 메시지 송신
        public void MSG_send(int i = -1)
        {
            StreamWriter streamWriter = new StreamWriter(tcpClient.GetStream()); // 송신을 위한 객체 생성
            streamWriter.AutoFlush = true; // 버퍼 최신화

            if (i == -1) // 자동회신이 아니면 실행
            {
                if (form1.SendMSG_box.Text == "") // 보낼 메시지가 공백이면 송신 안함
                {
                    return;
                }
                else if (Control_char_send(Control_char_check(), streamWriter) == 1) // 제어문자 양식인지 확인하고, 제어문자가 맞으면 송신
                {
                    return; // 제어문자 송신 성공 했으면 함수 종료
                }

                streamWriter.Write(form1.SendMSG_box.Text); // 메시지 송신
                Write_send(form1.SendMSG_box.Text); // 송신창 출력
                form1.SendMSG_box.Text = ""; // 송신 메시지창 초기화
                return;
            }

            streamWriter.Write(reply_send_MSG[i]); // 자동회신이면 송신
            Write_send(reply_send_MSG[i]); // 송신창 출력
        }

        // 제어문자 양식 확인, #와 #사이에 지정된 양식이 있으면 제어문자로 판단
        private string Control_char_check()
        {
            string text = form1.SendMSG_box.Text; // 보낼 메시지를 변수에 저장
            string text_string = ""; // 지정된 양식과 일치할 경우 문자열을 저장할 변수 생성

            int control_position = text.IndexOf("#", 0); // 문자열에서 # 찾음
            int jump_position = -1;
            try // IndexOf 사용시 배열을 벗어나면 발생하는 오류 방지
            {
                jump_position = text.IndexOf("#", control_position + 3, 2); // 제어문자가 3자리가 많기에 #부터 4칸 거리까지 # 찾기
            }
            catch (Exception)
            {
                try // IndexOf 사용시 배열을 벗어나면 발생하는 오류 방지
                {
                    jump_position = text.IndexOf("#", control_position + 3, 1); // 3칸 거리의 # 찾기
                }
                catch (Exception) { }
            }

            if (control_position != -1 && jump_position != -1) // # 2개가 일정거리 안에 위치하여 지정된 양식과 일치하면 실행
            {
                for (int i = control_position + 1; i < jump_position; i++) // #과 # 사이의 값들을 text_string 변수에 넣음
                {
                    text_string += text[i];
                }
                return text_string; // 제어문자 양식과 일치하는 문자열 반환
            }
            return "";
        }

        // 제어문자 확인 및 송신
        private int Control_char_send(string text_string, StreamWriter streamWriter)
        {
            if (text_string != "") // 제어문자 양식이 맞으면 실행
            {
                for (int i = 0; i < control_string.Length; i++) // 지정된 문자열이 제어문자 중에 있다면 실행
                {
                    if (text_string == control_string[i])
                    {
                        char text_char = (char)control_int[i]; // 제어문자와 대응되는 정수를 제어문자로 변환

                        if (char.IsControl(text_char)) // 제어문자 여부 최종확인
                        {
                            streamWriter.Write(text_char); // 제어문자 송신
                            Write_send($"제어문자 송신! {text_char}");
                            form1.SendMSG_box.Text = "";
                            return 1;
                        }
                    }
                }
            }
            return 0;
        }
    }
}
