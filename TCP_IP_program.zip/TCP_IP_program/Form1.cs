﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace TCP_IP_program
{
    public partial class Form1 : Form
    {
        public Server server = new Server();
        public Cli cli = new Cli();
        public Thread thread_server;
        public Thread thread_cli;

        public Form1()
        {
            InitializeComponent();
        }

        // 서버 실행
        private void Server_go_Click(object sender, EventArgs e)
        {
            thread_server = new Thread(() => server.Server_connect(this)); // 서버 연결
            thread_server.IsBackground = true; // 프로그램이 종료되면 스레드 종료 (스레드가 남는 것 방지)
            thread_server.Start(); // 스레드 시작
        }

        // 클라이언트 실행
        private void Cli_go_Click(object sender, EventArgs e)
        {
            thread_cli = new Thread(() => cli.Cli_connect(this)); // 클라이언트 연결
            thread_cli.IsBackground = true;
            thread_cli.Start();
        }

        // 자동회신 메시지 설정
        private void MSG_save_Click(object sender, EventArgs e)
        {
            if (thread_server != null) // 서버 스레드가 있으면 실행
            {
                server.Reply_MSG_save(); // 자동회신 받을 메시지와 보낼 메시지 저장
            }
            else if (thread_cli != null) // 클라이언트 스레드가 있으면 실행
            {
                cli.Reply_MSG_save();
            }
        }

        // 메시지 송신버튼 클릭
        private void MSG_send_Click(object sender, EventArgs e)
        {
            if (thread_server != null)
            {
                server.MSG_send(); // 메시지 송신
            }
            else if (thread_cli != null)
            {
                cli.MSG_send();
            }
        }

        // 엔터로 송신
        private void Enter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // 엔터로 송신
            {
                MSG_send_Click(sender, e);
            }
            else if (e.KeyCode == Keys.End) // 제어문자 전부 송신
            {
                if (thread_server != null)
                {
                    for (int i = 0; i < server.control_string.Length; i++)
                    {
                        SendMSG_box.Text = $"#{server.control_string[i]}#"; // 제어문자표의 제어문자들 입력
                        server.MSG_send();
                    }
                }
                else if (thread_cli != null)
                {
                    for (int i = 0; i < cli.control_string.Length; i++)
                    {
                        SendMSG_box.Text = $"#{cli.control_string[i]}#";
                        cli.MSG_send();
                    }
                }
            }
        }

        // 연결 중지 버튼 클릭
        private void Connect_stop_Click(object sender, EventArgs e)
        {
            if (thread_server != null)
            {
                server.Server_connect_stop(); // 연결 종료
            }
            else if (thread_cli != null)
            {
                cli.Cli_connect_stop();
            }
        }
    }
}
